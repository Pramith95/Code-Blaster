<?php

session_start();

unset($_SESSION['un']);

header("Location:login.php");





?>