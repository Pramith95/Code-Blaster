<!DOCTYPE html>
<html>
<head>
	<title>Mobile Shop</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
     <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
	<link rel="stylesheet" type="text/css" href="bootstrap\css\bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="bootstrap\js\bootstrap.min.js">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">


	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="row">
  <div class="col-sm-1">
    <div class="lr">
      <div class="logo">

      <img src="image/logo.png" class="img responsive" height="90px" width="110px">
        
      </div>
    </div>
    	
  </div>

  <div class="col-sm-10">
    
     <nav class="navbar navbar-inverse navbard navbar-fixed-top">
      
       <ul class="nav navbar-nav ">

        <li class="space"><a href="sign.php"><i class="fa fa-chevron-circle-up ispace"></i> Sign Up</a></li>
       </ul>
     
       </nav>
      <!--<div class="content2">

         <img src="images/sl1.jpg" class="img-responsive">
      
        -->
         <div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
    <li data-target="#myCarousel" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item content2 active">
      <img src="images/sl1.jpg" alt="Chania">
    </div>

    <div class="item content2">
      <img src="images/sl2.jpg" alt="Chania">
    </div>

    <div class="item content2">
      <img src="images/sl3.jpg" alt="Flower">
    </div>

    <div class="item content2">
      <img src="images/sl1.jpg" alt="Flower">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>










       
     
       <div class="content">
        <div class="row ">
         <div class="col-sm-4 im">
         	<img src="images/sl1.jpg" class="img-responsive">
         </div>

            <div class="col-sm-4 im">
         	<img src="images/sl1.jpg" class="img-responsive">
         </div>

            <div class="col-sm-4 im ">
         	<img src="images/sl1.jpg" class="img-responsive">
         </div>
       	
       </div>
       </div>
       <br>
       <br>

<div class="row">
<div class="col-sm-2">
</div>
<div class="col-sm-8">
<center><span style="font-weight: bold;font-size: 30px;">Sign In</span></center><br><br>
<div class="form-group log">
<form action="main.php" name="f1" method="POST">

<label for="username">Username</label>
<input type="text" name="un" class="form-control" placeholder="Enter Username" required><br>
<label for="password">Password</label>
<input type="password" class="form-control"  name="ps" placeholder="Enter Password" required><br>

<center><button type="submit" class="btn btn-success">Sign In</button></center>
  

</form>
</div><br><br>
<?php

if(isset($_GET['value']))
{
   
   echo "<div style=\"margin-left:300px;\" class=\"alert alert-danger\">
  <strong>Sign in Failed!</strong>  Wrong Username And Password
   </div><br>";
    
}



?>
</div>
<div class="col-sm-2">
</div>
</div>
<div class="footerlast">

<div class="lastcontent">EMC Mobile Shop</div>
  
</div>
 
  </div>
	
</div>

</body>
</html>