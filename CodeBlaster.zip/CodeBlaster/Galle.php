
<!DOCTYPE html>
<html>
<head>
	<title>EMC Mobile Galle</title>

	<link rel="stylesheet" href="css/bootstrap.min.css">
		 <link rel="stylesheet" href="css/font-awesome.min.css">
		<link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="css/main.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap\css\bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="bootstrap\js\bootstrap.min.js">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">


	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body>


   <div class="row">
  <div class="col-sm-1">
    <div class="lr">
      <div class="logo">

      <img src="image/logo.png" class="img responsive" height="90px" width="110px">
        
      </div>
    </div>
    	
  </div>

  <div class="col-sm-10">
    
     <nav class="navbar navbar-inverse navbard navbar-fixed-top">
      
       <ul class="nav navbar-nav ">
        <li class="item"><a href="main.php">Home</a></li>
        <li class="item2"><a href="Galle.php">EMC Mobile Galle</a></li>
        <li class="item2"><a href="iphone.php">Iphone</a></li>
        <li class="item2"><a href="cart.php">My Cart</a></li>
        
        <li class="space"><a href="logout.php"><i class="fa fa-power-off ispace"></i>Logout</a></li>
       </ul>
     
       </nav>

     <div class="hbar">
     	<div class="glyphicon glyphicon-home" style="margin-left:80px"> >  <span style="font-family:Verdana">Smart Phone</span></div> 
     

     </div>

    <div class="pbar">
     <div class="row">
       
       <div class="col-sm-1 ">

            
             <div class="picbar"> <img src="images/ms.jpg"  class="img-responsive"></div>
             <div class="picbar"> <img src="images/ms.jpg"  class="img-responsive"></div>
             <div class="picbar"> <img src="images/ms.jpg"  class="img-responsive"></div>
             <div class="picbar"> <img src="images/ms.jpg"  class="img-responsive"></div>

       </div>
       
        
        <div class="col-sm-5">

            
              <div class="bbar"><div class="pcbar"><img src="images/ms.jpg" height="470px" class="img-responsive"></div></div>
            

       </div>
  
     
       <div class="col-sm-10">

        
         	<div class="dbar">
         	 <div class="cbar">Model</div> 
         	<div class="btnc"><b>Android</b></div><br><br>
         	<div style="font-size:20px;">Sony</div><br>
         	<div style="font-size:20px;">Rs 25000</div><br><br>

         	
         	<form action="cart.php" name="f1" method="POST">
 
         	<!--<a href="#"><div class="gbar"><div class="r"></div></div></a>
         	<a href="#"><div class="gbar"><div class="b"></div></div></a>
         	<a href="#"><div class="gbar"><div class="p"></div></div></a><br><br>-->
          <label for="ta">Name</label>
          <input type="text" name="name" class="form-control" value="XZ2" readonly><br><br>
         	<p>External Memory</p>
         	<select name="siz" class="sw" value="select" required>
         	<option value="16 GB">16 GB</option>	
         	<option value="32 GB">32 GB</option>	
         	<option value="64 GB">64 GB</option>	


         	</select><br><br>
          <label for="ta">Price</label>
          <input type="text" name="price" class="form-control" value="RS 25000" readonly><br><br>

         	<p>Color</p>
         	
         	<label class="radio-inline"><input type="radio" name="chk" value="Red">Red  
         	</label>

         	<label class="radio-inline"><input type="radio" name="chk" value="Blue">Blue  
         	</label>

         	<label class="radio-inline"><input type="radio" name="chk" value="Pink">Pink
         	</label><br>
         	<button type="submit" class="btnsubmit"><span class="glyphicon glyphicon-shopping-cart gly"></span>ADD TO CART</button>
         	</form><br><br>
         	<div class="glya"><a href="#"><span class="glyphicon glyphicon-heart gly "></span>Add To Whistlist</a></div><br><br>

         	<img src="images/pay.jpg" class="img-responsive"><br>

         	



         	</div>



        
       	
       </div>
       


       </div><br><br>

        <div class="row">

          <div class="col-sm-12">
          	

          	


          	  <div class="tab-content">
          	   <div id="minfo" class="tab-pane fade in active">
          	  	<br><p>Avalible</p>

          	  </div>

          	  <div id="ds" class="tab-pane fade">
          	  <br> <p>Display. 9.70-inch.</p>
    <p>Processor. 1.3GHz.</p>
    <p>Front Camera. 1.2-megapixel.</p>
    <p>Resolution. 1536x2048 pixels.</p>
    <p>RAM. 1GB.</p>
    <p>OS. Windows 8.</p>
    <p>Storage. 16GB.</p>
    <p>Rear Camera. 5-megapixel.</p>
          	  	

          	  </div>

          	  <div id="down" class="tab-pane fade">
          	  	
                  <a class="dla" href="#"><div class="dl"><span  class="glyphicon glyphicon-download-alt"></span><span style="margin-left:10px; text-decoration:none;" >Download</span></div></a>
           	 
          	  </div>

          	  <div id="ps" class="tab-pane fade">
          	  	
          	  	<br><p>AFTER SAVING YOUR CUSTOMIZED PRODUCT, REMEMBER TO ADD IT TO YOUR CART. 
ALLOWED FILE FORMATS ARE: GIF, JPG, PNG

PICTURES</p>
   <form action="action.php" naem="f2">
   <input type="file" name="image">
   </form>
          	  </div>

          	  <div id="vf" class="tab-pane fade">
          	  	

                <iframe width="560" height="315" src="https://www.youtube.com/embed/W_cBXA99Cwg" frameborder="0" allowfullscreen></iframe>
          	  	
          	  </div>


          	  </div>



        </div>


        
        	





        </div>




        <div class="row">
          <div class="col-sm-3">
          	<div class="re">
               <br><br><b>Reviews</b>
          	  <div class="gr">
          	   

          	  	
          	  </div>
          		
          	</div>
          
          </div>

          <div class="col-sm-9">
          	 
          	 <div class="re">
               
          	  <div class="grr">
          	   
            

<






          </div>

         </div>


         <div class="row">
          <div class="col-sm-12">
            <div class="brd">
            	
            </div>
           </div>
           </div>


           


           <div class="col-sm-3">
              <h3 style="color:white;">Catagories</h3>
              <div class="vm">
              <ul>
               <li><a href="#">Iphone</a></li>
               <li><a href="#">Samsung</a></li>
               <li><a href="#">HTC</a></li>
               <li><a href="#">Symphony</a></li>
               <li><a href="#">Walton</a></li>
               <li><a href="#">Nexux</a></li>
               
             </ul>
             </div>


          	
          </div>


       </div>

       </div>
       </div>
        
        <div class="footerlast">

    <div class="lastcontent">EMC Mobile Shop</div>
    	
    </div>

       </div> 
  </div>
	
</div>

</body>
</html>